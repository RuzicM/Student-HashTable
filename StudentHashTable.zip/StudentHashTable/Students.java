import java.util.*;
import java.util.stream.Collectors;

public class Students {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = "";
        int grade = 0;

        ArrayList<String> list = new ArrayList<>();
        SimpleHashtable<String, List<Integer>> student = new SimpleHashtable<>(2);

        while (true) {
            System.out.println("Enter student input and grade");
            input = scanner.nextLine();
            String[] split = input.split("\\s+");
            String name = split[0];
            if (name.equals("KRAJ")) {
                print(list, student);
                break;
            }
            grade = Integer.parseInt(split[1]);
            if (!student.containsKey(name)) {
                List<Integer> aList = new ArrayList<>();
                list.add(name);
                student.put(name, aList);
                System.out.println("Adding new.");
            }

            addGrades(student, name, grade);
        }

    }

    public static void addGrades(SimpleHashtable<String, List<Integer>> student, String name, int grade) {
        List<Integer> studentName = student.get(name);
        studentName.add(grade);

    }

    public static double average(List<Integer> numbers) {
        double sum = 0;
        for (Integer number : numbers) {
            sum += number;
        }
        return sum / numbers.size();
    }

    public static double deviation(List<Integer> numbers) {
        double means = average(numbers);
        double standardDeviation = 0.0;
        int size = numbers.size() ;

        for (Integer integer : numbers) {
            standardDeviation += Math.pow(integer - means, 2);

        }

        standardDeviation = standardDeviation / size;

        return Math.sqrt(standardDeviation);
    }


    public static void print(List<String> list, SimpleHashtable<String, List<Integer>> student) {

        for (int i = 0; i < list.size(); i++) {
            String name = list.get(i);
            List<Integer> grades = student.get(name);
            System.out.println("Student " + name);
            System.out.print("Grades:");
            grade(grades);
            System.out.println();
            System.out.println("Unique grades: " + uniqueGrades(grades));
            System.out.println(" Average: " + average(grades));
            System.out.println("Standard deviation: " + deviation(grades));

        }
    }

    public static Set<Integer> uniqueGrades(List<Integer> numbers) {
        Set<Integer> uniqueGrades = new HashSet<>(numbers);

        return uniqueGrades;
    }

    public static void grade(List<Integer> numbers) {
        for (int grade : numbers) {
            System.out.print(grade + ",");
        }
    }


}