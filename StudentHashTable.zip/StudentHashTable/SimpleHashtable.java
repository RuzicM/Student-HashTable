import jdk.nashorn.internal.ir.CallNode;
import sun.awt.X11.XWMHints;

public class SimpleHashtable<K, V> {
    TableEntry<K, V>[] table;
    private int size;

    public SimpleHashtable(int size) {
        int i = 2;
        while (i < size) {
            i *= 2;
        }
        table = (TableEntry<K, V>[]) new TableEntry[i];
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty(K key) {
        int hashedKey = hashCode(key);
        return table[hashedKey] == null;

    }

    public boolean containsKey(K key) {
        int hashedKey = hashCode(key);

        TableEntry temp = table[hashedKey];
        if (isEmpty(key)) {
            return false;
        }
        if (!isEmpty(key)) {
            while (!temp.key.equals(key)) {
                if (temp.next == null) {
                    return false;
                } else {
                    temp = temp.next;

                }
            }
        }
        return true;
    }


    public void remove(K key) {
        int hashedKey = hashCode(key);
        TableEntry temp = table[hashedKey];
        if (isEmpty(key)) {
            return;
        }
        while (temp.next != null && temp.next.key != key) {
            temp = temp.next;
        }

        if (temp.next != null) {
            temp.next = temp.next.next;
            size--;
        }

    }

    public V get(K key) {
        int hashedKey = hashCode(key);
        TableEntry temp = table[hashedKey];
        if (temp.key == key) {
            return (V) temp.value;
        } else {
            while (!temp.key .equals(key)) {
                temp = temp.next;

                if (temp==null){
                    return null;
                }

                if (temp.key == null) {
                    break;
                }
            }
            return (V) temp.value;
        }
    }


    public void put(K key, V value) {
        int hashedKey = hashCode(key);
        TableEntry<K, V> temp = table[hashedKey];
        if (isEmpty(key)) {
            table[hashedKey] = new TableEntry<K, V>(key, value);
            size++;
        } else {
            while (temp.next != null) {
                if (temp.key == key) {
                    temp.value = value;
                    return;
                }
                temp = temp.next;
            }
            temp.next = new TableEntry<K, V>(key, value);
            size++;
        }
    }


    public int hashCode(K key) {
        return Math.abs(key.hashCode() % table.length);
    }


    private static class TableEntry<K, V> {

        private K key;
        private V value;
        TableEntry<K, V> next;


        public TableEntry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public TableEntry() {
        }


        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }

        public void setValue(V value) {
            this.value = value;
        }

    }

    public static void main(String[] args) {
        SimpleHashtable<String, Integer> list = new SimpleHashtable<>(2);
        list.put("Ivana", 5);
        list.put("Ante", 2);
        list.put("Jasna", 2);
        list.put("Kristina", 5);
        list.put("Ivana", 3);

        list.remove("Jasna");
        Integer kristina=list.get("Kristina");

        System.out.println(kristina);


    }


}
